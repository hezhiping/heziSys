﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hezi
{
    public partial class Form1 : Form
    {
       string[] str ={ 
                          "星期三，是？"
                          ,
                          "星你很爱我是吧！"
                          ,
                          "你想学习？"
                          ,
                          "你是不是很想学习怎么爱我？"
                          ,
                          "那就开始吧！"
                          ,
                          "首先，把JJ拿到手里抚摸，用舌尖轻轻触碰他的JJ头和头前面的眼，动作要轻柔，缓慢。然后张开嘴把JJ含到嘴里，能含进去多少是多少，用你的舌头在口腔里搅动，用舌根包裹住他的JJ头抚摸，慢慢的把整个JJ往肚子里吞，等全部吞进去以后，过几秒钟再慢慢的抽出来，这个时候不能全部拔出，抽到han住他的鸡鸡前面，在嘴里就可以了。然后接着重复刚才的动作，一进一出，周而复始，手部动作可以抚摸他的蛋蛋，也可以用嘴去han住，不过蛋蛋比较敏感，一定要轻，否则会痛的。如果你想尽快给他口交出来，那就要加快速度，你可以掌握住口交的节奏，JJ放到嘴里，头一前一后的摆动，嘴里做用力吸允的感觉，然后加快动作。假如你可以把一整根JJ全部吞下去，只要用你最快的速度吞吐，不用吸几下，你男友就会射了。射的时候也要注意，不管你要不要把精子吃下去，都不要把他的JJ从嘴里拿出来，男人肯定是喜欢射到里面的，因为she精时是很脆弱的，突然的温度改变或者心理改变，都会导致she精不畅，血管堵塞之类，严重充血的话也许还会影响以后的性功能。所以最好不要拿出来，如果咽下去了也没关系，精子对身体无害的，等他全部射完以后，继续慢慢进行刚才的动作，多吸允一会，让你的温柔继续，把剩余的精子全部吸出来后JJ就会变软变小，这个时候再慢慢的放出来。就算完成了！"
                          ,                      
                            "是不是还很想要！"
                          ,
                           "是不是发现不能关闭？"
                          ,
                          "想知道怎么关闭？"
                          ,
                          "赶紧说三句我很爱你，说了？"
                          ,
                            "发现上当了？"
                          ,
                           "还没完呢"
                          ,
                          "想打我？"
                          ,
                          "那你来啊！"
                      };


        int count = 0;
        public Form1()
        {

            InitializeComponent();
            this.ShowInTaskbar = false;
            //SetVisibleCore(false);           
        }
        protected override void SetVisibleCore(bool value)
        {
            base.SetVisibleCore(value);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //获取当前工作区宽度和高度（工作区不包含状态栏）
            int ScreenWidth = Screen.PrimaryScreen.WorkingArea.Width;
            int ScreenHeight = Screen.PrimaryScreen.WorkingArea.Height;
            //计算窗体显示的坐标值，可以根据需要微调几个像素
            int x = 0;
            int y = 0;

            x = (ScreenWidth - this.Width) / 2;
            y = (ScreenHeight - this.Height) / 2;
            this.Location = new Point(x, y);           
            this.textBox1.Text = "来了";
        }

        private void button1_Click(object sender, EventArgs e)
        {

            for (int i = 0; i < str.Length; i++)
            {
                this.textBox1.Text = str[i];
            }

            //this.Close();
        }



    }
}
